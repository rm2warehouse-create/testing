"""
URL configuration for hemboard project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from ast import pattern
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from hemtracking import views as hemtracking_views

from dailystock import views as dailystock_views
urlpatterns = [
    path('admin/', admin.site.urls),

    path('home/', hemtracking_views.home, name='home'),
  # Dashboard summary view (Excel → dashboard.html)
    path('dashboard/', dailystock_views.stock_dashboard, name='dashboard'),

    # Simple home view (just loads dashboard.html)
    path('home2/', dailystock_views.home2, name='home2'),


]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    
    
