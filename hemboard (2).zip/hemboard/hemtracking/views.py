from django.shortcuts import render
   

import pandas as pd

from django.shortcuts import render
from django.http import HttpResponse





import json
def home(request):

    file_path = r"C:\Users\Godown\Videos\hehem.xlsx"

    df = pd.read_excel(file_path)

    df = df.fillna(0)

    df.columns = [
        "size",
        "gsm",
        "mill_stock",
        "kg",
        "phy_stock"
    ]

    # ROUND VALUES

    df["mill_stock"] = df["mill_stock"].round(2)
    df["kg"] = df["kg"].round(2)
    df["phy_stock"] = df["phy_stock"].round(2)

    # TOTALS

    total_stock = round(
        df["phy_stock"].sum(), 2
    )

    total_kg = round(
        df["kg"].sum(), 2
    )

    total_mill_sheets = round(
        df["mill_stock"].sum(), 2
    )

    total_mill_kg = round(
        df["kg"].sum(), 2
    )

    low_stock = len(
        df[df["phy_stock"] < 5000]
    )

    # CHART

    chart_labels = json.dumps(
        df["gsm"].astype(str).tolist()
    )

    chart_data = json.dumps(
        df["kg"].tolist()
    )

    # TABLE DATA

    data = df.to_dict(
        orient="records"
    )

    context = {

        "data": data,

        "total_stock": total_stock,

        "total_kg": total_kg,

        "low_stock": low_stock,

        "total_mill_sheets":
        total_mill_sheets,

        "total_mill_kg":
        total_mill_kg,

        "chart_labels":
        chart_labels,

        "chart_data":
        chart_data,
    }

    return render(
        request,
        "name.html",
        context
    )