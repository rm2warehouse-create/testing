from django.apps import AppConfig


class HemtrackingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hemtracking'
