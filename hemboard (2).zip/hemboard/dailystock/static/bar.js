document.addEventListener("DOMContentLoaded", () => {

    // --- 1. PREMIUM PAGE NAVIGATION SYSTEM ---
    const menuButtons = document.querySelectorAll(".menu-btn");
    const pages = document.querySelectorAll(".page");

    menuButtons.forEach(button => {
        button.addEventListener("click", () => {
            const targetPageId = button.getAttribute("data-page");

            // Sidebar Active State Class Update
            menuButtons.forEach(btn => btn.classList.remove("active"));
            button.classList.add("active");

            // Page Switching with Smooth Glass-Fade Opacity Effect
            pages.forEach(page => {
                page.style.opacity = "0";
                page.classList.remove("active");

                if (page.id === targetPageId) {
                    // Timeout allows CSS transitions to sync flawlessly
                    setTimeout(() => {
                        page.classList.add("active");
                        page.style.opacity = "1";
                    }, 50);
                }
            });
        });
    });

    // --- 2. ULTRA-FAST REAL-TIME SEARCH FILTER ---
    const searchInput = document.getElementById("tableSearch");

    if (searchInput) {
        searchInput.addEventListener("input", (e) => {
            const searchTerm = e.target.value.toLowerCase().trim();

            // Active Section-la irukura Table body-ah mattum target pannum
            const activePage = document.querySelector(".page.active");
            if (!activePage) return;

            const tableRows = activePage.querySelectorAll(".premium-table tbody tr");

            tableRows.forEach(row => {
                // Ignore Empty Placeholder rows
                if (row.classList.contains("empty-state")) return;

                const rowText = row.textContent.toLowerCase();

                if (rowText.includes(searchTerm)) {
                    row.style.display = ""; // Show Row
                } else {
                    row.style.display = "none"; // Hide Row
                }
            });
        });
    }

    // --- 3. AUTO LIVE BUTTON PULSE GLOW TRIGGER ---
    const liveBtn = document.querySelector(".live-btn");
    if (liveBtn) {
        liveBtn.addEventListener("click", () => {
            liveBtn.style.transform = "scale(0.95)";
            setTimeout(() => { liveBtn.style.transform = "none"; }, 100);

            // Console monitor verification logs
            console.log("PGS ERP System: Live Sync Force Polling Triggered.");
        });
    }
});