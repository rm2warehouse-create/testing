const pages = document.querySelectorAll('.page');
const btns = document.querySelectorAll('.nav-btn');
const search = document.getElementById('search');

btns.forEach(b => {
    b.onclick = () => {
        btns.forEach(x => x.classList.remove('active'));
        b.classList.add('active');

        pages.forEach(p => p.classList.remove('active'));
        document.getElementById(b.dataset.page).classList.add('active');
    }
});

// counter animation
document.querySelectorAll('.counter').forEach(el => {
    let t = parseInt(el.innerText) || 0;
    let c = 0;
    let i = setInterval(() => {
        c += t / 40;
        el.innerText = Math.floor(c);
        if (c >= t) clearInterval(i);
    }, 20);
});

// live clock
setInterval(() => {
    document.getElementById("clock").innerText =
        new Date().toLocaleString();
}, 1000);


function showMat(id) {
    document.querySelectorAll('.mat-table').forEach(t => {
        t.classList.remove('active');
    });

    document.querySelectorAll('.tab-btn').forEach(b => {
        b.classList.remove('active');
    });

    document.getElementById(id).classList.add('active');
    event.target.classList.add('active');
}