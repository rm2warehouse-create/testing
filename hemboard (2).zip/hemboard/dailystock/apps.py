from django.apps import AppConfig


class DailystockConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dailystock'
