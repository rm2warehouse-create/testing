from django.shortcuts import render

# Create your views here.
# views.py
from django.shortcuts import render
import pandas as pd
from datetime import datetime
from django.shortcuts import render
import pandas as pd
from datetime import datetime
from django.shortcuts import render
import pandas as pd

from django.shortcuts import render
import pandas as pd

from django.shortcuts import render
import pandas as pd

def stock_dashboard(request):

    file_path = r"\\192.168.0.251\public\public\PGS\office physical stock JULY.xlsx"

    material_sheets = [
        "RELLS STOCK",
        "FBB",
        "GREY BACK",
        "CARTE LUMINA",
        "WHITE BACK",
        "SAFIRE GRAFIC",
        "KRAFT",
        "ART PAPER & ART CARD & STICKER"
    ]

    party_sheets = [
        "BHASKAR",
        "SHALIMAR",
        "RAJDHANI",
        "KOYAS",
        "RAJ FRAGRANCE",
        "FOREST",
        "SHAKUNTHALA",
        "ORKAY",
        "ORKAY SB(RAVI KUMAR)",
        "DONTI",
        "VIJAYALAKSHMI",
        "M.M",
        "PRAGATHI",
        "MANJUSHREE",
        "GURU PACKAGGING"
    ]

    material_summary = []
    party_summary = []

    # MATERIAL SUMMARY
    for sheet in material_sheets:

        try:
            df = pd.read_excel(file_path, sheet_name=sheet, header=1)
            df.columns = df.columns.str.strip()
            df = df.fillna(0)

            if "AVILABLE STOCK AFTER ISSUE QUT." not in df.columns:
                continue

            filtered = df[df["AVILABLE STOCK AFTER ISSUE QUT."] > 0]

            if sheet == "ART PAPER & ART CARD & STICKER" and "catagery" in df.columns:

                grouped = filtered.groupby("catagery").agg({
                    "AVILABLE STOCK AFTER ISSUE QUT.": "sum",
                    "phy KG": "sum"
                }).reset_index()

                for _, row in grouped.iterrows():
                    material_summary.append({
                        "sheet": sheet,
                        "category": row["catagery"],
                        "qty": int(float(row["AVILABLE STOCK AFTER ISSUE QUT."])),
                        "kg": round(float(row["phy KG"]), 2)
                    })

            elif sheet == "RELLS STOCK" and "CATEGARY" in df.columns:

                grouped = filtered.groupby("CATEGARY").agg({
                    "AVILABLE STOCK AFTER ISSUE QUT.": "sum",
                    "phy KG": "sum"
                }).reset_index()

                for _, row in grouped.iterrows():
                    material_summary.append({
                        "sheet": sheet,
                        "category": row["CATEGARY"],
                        "qty": int(float(row["AVILABLE STOCK AFTER ISSUE QUT."])),
                        "kg": round(float(row["phy KG"]), 2)
                    })

            else:
                material_summary.append({
                    "sheet": sheet,
                    "category": "-",
                    "qty": int(float(filtered["AVILABLE STOCK AFTER ISSUE QUT."].sum())),
                    "kg": round(float(filtered["phy KG"].sum()), 2)
                })

        except:
            pass

    # PARTY SUMMARY
    for sheet in party_sheets:

        try:
            df = pd.read_excel(file_path, sheet_name=sheet, header=1)
            df.columns = df.columns.str.strip()
            df = df.fillna(0)

            if "CATAGERY" not in df.columns:
                continue

            filtered = df[df["AVILABLE STOCK AFTER ISSUE QUT."] > 0]

            grouped = filtered.groupby("CATAGERY").agg({
                "AVILABLE STOCK AFTER ISSUE QUT.": "sum",
                "phy KG": "sum"
            }).reset_index()

            for _, row in grouped.iterrows():
                party_summary.append({
                    "party": sheet,
                    "category": row["CATAGERY"],
                    "qty": int(float(row["AVILABLE STOCK AFTER ISSUE QUT."])),
                    "kg": round(float(row["phy KG"]), 2)
                })

        except:
            pass

    # FBB ABOVE 1 TON
    fbb_jobs = []

    try:
        df = pd.read_excel(file_path, sheet_name="FBB", header=1)
        df.columns = df.columns.str.strip()
        df = df.fillna(0)

        df = df[df["phy KG"] >= 1000]

        for _, row in df.iterrows():
            fbb_jobs.append({
                "size": row.get("SIZE", ""),
                "gsm": row.get("GSM", ""),
                "job": row.get("job name", ""),
                "qty": row.get("AVILABLE STOCK AFTER ISSUE QUT.", 0),
                "kg": row.get("phy KG", 0),
                "ton": round(float(row.get("phy KG", 0)) / 1000, 2)
            })

    except:
        pass

    # GREY BACK ABOVE 1 TON
    gb_jobs = []

    try:
        df = pd.read_excel(file_path, sheet_name="GREY BACK", header=1)
        df.columns = df.columns.str.strip()
        df = df.fillna(0)

        df = df[df["phy KG"] >= 1000]

        for _, row in df.iterrows():
            gb_jobs.append({
                "size": row.get("SIZE", ""),
                "gsm": row.get("GSM", ""),
                "job": row.get("JOB NAME", ""),
                "qty": row.get("AVILABLE STOCK AFTER ISSUE QUT.", 0),
                "kg": row.get("phy KG", 0),
                "ton": round(float(row.get("phy KG", 0)) / 1000, 2)
            })

    except:
        pass

    return render(request, "dashboard.html", {
        "material": material_summary,
        "party": party_summary,
        "fbb_jobs": fbb_jobs,
        "gb_jobs": gb_jobs,

        "total_material_qty": sum(x["qty"] for x in material_summary),
        "total_material_kg": sum(x["kg"] for x in material_summary),
        "total_party_kg": sum(x["kg"] for x in party_summary),
        "above_one_ton_count": len(fbb_jobs) + len(gb_jobs),
    })
# 👉 Simple home view
def home2(request):
    return render(request, "dashboard1.html")

